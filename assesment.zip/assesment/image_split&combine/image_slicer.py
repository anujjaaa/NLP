# Image path, number of rows
# and number of columns
# should be provided as an arguments
import cv2
import sys
import os
import glob
import fnmatch
import re
import numpy as np
from PIL import Image

image1, image2, image3, image4 = [], [], [], []
path = 'patches/'


def split_image(img):
    # split image into
    nRows = 4
    mCols = 4

    # Dimensions of the image
    sizeX = img.shape[1]
    sizeY = img.shape[0]

    print(img.shape)


    for i in range(0, nRows):
        for j in range(0, mCols):
            roi = img[int(i*sizeY/nRows):int(i*sizeY/nRows) + int(sizeY/nRows), int(j*sizeX/mCols):int(j*sizeX/mCols) + int(sizeX/mCols)]
            # cv2.imshow('rois'+str(i)+str(j), roi)
            cv2.imwrite(path + 'patch_'+str(i)+str(j)+".jpg", roi)
    print('Sucessfully split image into 4x4 grid')
    cv2.waitKey()


def combine():
    image_list = []
    for filename in glob.glob('*.jpg'):
        image_list.append(filename)
	print('list : ', image_list)
    for i in image_list:
        name = os.path.basename(i)
        if fnmatch.fnmatch(name, 'patch_0*.jpg'):
            image1.append(os.path.join(path, i))
            (image1.sort(key=lambda f: int(re.sub('\D', '', f))))
        elif fnmatch.fnmatch(name, 'patch_1*.jpg'):
            image2.append(os.path.join(path, i))
            (image2.sort(key=lambda f: int(re.sub('\D', '', f))))
        elif fnmatch.fnmatch(name, 'patch_2*.jpg'):
            image3.append(i)
            (image3.sort(key=lambda f: int(re.sub('\D', '', f))))
        else:
            image4.append(i)
            (image4.sort(key=lambda f: int(re.sub('\D', '', f))))

    Image1 = [Image.open(i) for i in image1]  # ['patch_00.jpg', 'patch_01.jpg', 'patch_02.jpg', 'patch_03.jpg'])]
    Image2 = [Image.open(i) for i in image2]  # (['patch_10.jpg', 'patch_11.jpg', 'patch_12.jpg', 'patch_13.jpg'])]
    Image3 = [Image.open(i) for i in image3]  # (['patch_20.jpg', 'patch_21.jpg', 'patch_22.jpg', 'patch_23.jpg'])]
    Image4 = [Image.open(i) for i in image4]  # (['patch_30.jpg', 'patch_31.jpg', 'patch_32.jpg', 'patch_33.jpg'])]


    min_shape = sorted([(np.sum(i.size), i.size) for i in Image1])[0][1]
    img1_comb = np.hstack((np.asarray(i.resize(min_shape))for i in Image1))
    img2_comb = np.hstack((np.asarray(i.resize(min_shape))for i in Image2))
    img3_comb = np.hstack((np.asarray(i.resize(min_shape))for i in Image3))
    img4_comb = np.hstack((np.asarray(i.resize(min_shape))for i in Image4))

    imgs_comb = np.vstack((img1_comb, img2_comb, img3_comb, img4_comb))
    imgs_comb = Image.fromarray(imgs_comb)
    imgs_comb.save('output.jpg')
    imgs_comb.show()
    print('Successfully combined sub-blocks from images to form original image')


if __name__ == '__main__':
    img = cv2.imread('sample.jpeg')
    split_image(img)
    combine()
